<template>
  <div class="main">
    <!-- 顶部信息 -->
    <section class="top">
      <div class="left">
        <el-image
          src="https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg"
        ></el-image>
        <section>
          <p>程序员说</p>
          <p> <span>会员免费</span> <span>更新至第10期｜更新中</span> </p>
        </section>
      </div>
      <el-button type="text" icon="el-icon-edit">编辑</el-button>
    </section>
    <!-- 表格 -->
    <section class="table">
      <el-table :data="tableData" stripe style="width: 100%">
        <el-table-column prop="date" label="日期" width="180"> </el-table-column>
        <el-table-column prop="name" label="姓名" width="180"> </el-table-column>
        <el-table-column prop="address" label="地址"> </el-table-column>
      </el-table>
    </section>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue'
  export default defineComponent({
    setup() {
      const tableData = [
        {
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄'
        },
        {
          date: '2016-05-04',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1517 弄'
        },
        {
          date: '2016-05-01',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1519 弄'
        },
        {
          date: '2016-05-03',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1516 弄'
        }
      ]
      return {
        tableData
      }
    }
  })
</script>

<style scoped lang="scss">
  .main {
    background: #ffffff;
    padding: 32px 24px;
  }
  .top {
    height: 120px;
    padding: 16px;
    background: #f0f0f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-sizing: border-box;
    -moz-box-sizing: border-box; /* Firefox */
    -webkit-box-sizing: border-box; /* Safari */
    .left {
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: #666666;
      letter-spacing: 1px;
      section {
        padding-left: 10px;
      }
    }
    ::v-deep .el-image {
      img {
        width: 136px;
        height: 88px;
      }
    }
  }
</style>
