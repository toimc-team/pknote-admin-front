import content from '@/views/content-manage/lesson/content.vue'

const lesson = [
  {
    path: '/content-manage/lesson/content',
    component: content
  }
]

export default lesson
